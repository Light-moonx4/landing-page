function siguiente(){
    window.location.href = "present.html";
}
document.getElementById("pagina2").addEventListener("click",siguiente);