function atras(){
    window.location.href = "index.html";
}
document.getElementById("principal").addEventListener("click",atras);